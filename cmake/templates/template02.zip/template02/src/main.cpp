#include <iostream>

using namespace std;

#include <Calculator.hpp>

int
main()
{
    My::Calculator calculator;
    std::cout << "(2 + 2) = " << calculator.add(2, 2) << std::endl;
}
