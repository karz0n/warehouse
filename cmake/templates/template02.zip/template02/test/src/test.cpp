#include <gtest/gtest.h>

TEST(Test, Dummy)
{
    EXPECT_TRUE(true);
}
