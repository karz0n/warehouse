#pragma once

#include "template02_export.h"

#include <memory>

namespace My {

class TEMPLATE02_EXPORT Calculator {
public:
    Calculator();

    ~Calculator();

    int
    add(int arg1, int arg2);

private:
    std::unique_ptr<class CalculatorImpl> _impl;
};

} // namespace My
