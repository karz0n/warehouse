#include "CalculatorImpl.hpp"

namespace My {

int
CalculatorImpl::add(int arg1, int arg2)
{
    return (arg1 + arg2);
}

} // namespace My
