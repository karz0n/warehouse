#pragma once

namespace My {

class CalculatorImpl {
public:
    int
    add(int arg1, int arg2);
};

} // namespace My
