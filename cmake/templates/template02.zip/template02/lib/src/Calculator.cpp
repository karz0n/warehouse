#include "Calculator.hpp"

#include "CalculatorImpl.hpp"

namespace My {

Calculator::Calculator()
    : _impl{new CalculatorImpl}
{
}

Calculator::~Calculator()
{
}

int
Calculator::add(int arg1, int arg2)
{
    return _impl->add(arg1, arg2);
}

} // namespace My
